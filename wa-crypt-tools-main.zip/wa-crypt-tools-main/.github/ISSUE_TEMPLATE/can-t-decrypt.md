---
name: Can't decrypt
about: The program can't decrypt my files
title: ''
labels: ''
assignees: ElDavoo

---

**Hexdump of your key file**
Add the hexdump of your key file here

**Hexdump of the encrypted DB
Add the hexdump of the first 256 bytes of your DB here.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Program output using -v and -f**
 

**Additional context**
Add any other context about the problem here.
