from unittest import TestCase


class TestDatabase(TestCase):
    pass
