# Security Policy

## Supported Versions

Latest

## Reporting a Vulnerability

Open an issue or contact me in my profile's email
