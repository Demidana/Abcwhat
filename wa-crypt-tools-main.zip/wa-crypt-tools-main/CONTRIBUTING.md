# How to contribute

## Test

Test the program with your own databases, both crypt 12, crypt14 and crypt15. Report any errors.

## Work on issues

Take a look at the open issues and work on them

## Submitting changes

Open a pull request

## Coding conventions

Those of PyCharm
