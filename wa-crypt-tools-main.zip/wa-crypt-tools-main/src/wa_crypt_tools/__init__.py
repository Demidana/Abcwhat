import logging
l = logging.getLogger(__name__)

l.addHandler(logging.NullHandler())